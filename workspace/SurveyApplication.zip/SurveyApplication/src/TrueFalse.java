import java.util.Scanner;

public class TrueFalse extends MC {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public TrueFalse(){
		
	}
	/*Get the Prompt from the user for the T/F*/
	public void getPrompt() {
		
		System.out.println("Enter the prompt for your True/False question:");
		@SuppressWarnings("resource")
		Scanner sc = new Scanner(System.in);
		String i = sc.nextLine();
		SetPrompt(i +"\n");
	
	}
	/*Sets the question and adds True and False to the choices vector*/
	public void setQuestion() {
		getPrompt();
		choices.add("True"); choices.add("False");
	}
	/*Modify the question(coming soon)*/
	public void Modify() {
		
	}
}
