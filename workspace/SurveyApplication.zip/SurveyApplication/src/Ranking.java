import java.util.Scanner;

public class Ranking extends Matching {

		/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

		public Ranking(){
			
		}
		/*Get the Prompt from the user for the ranking*/
		public void getPrompt() {
			
			System.out.println("Enter the prompt or your ranking ranking question:");
			@SuppressWarnings("resource")
			Scanner sc = new Scanner(System.in);
			String i = sc.nextLine();
			SetPrompt(i +"\n");
		}
		/*Sets the question*/
		public void setQuestion(){
			getPrompt();
			System.out.println("Enter the number of choices to rank");
			@SuppressWarnings("resource")
			Scanner sc = new Scanner(System.in);
			while (!sc.hasNextInt()) {
				   System.out.println("int, please!");
				   sc.nextLine();
				}
			int n = sc.nextInt();
			setList(n);
		}
		
		/*sets the right and left lit for the Ranking*/
		public void setList(int n){
			
			System.out.println("Enter the choices to rank");
			for( int i=1; i<=n;i++){
				System.out.println("Enter choice " + "#"+i+".");
				@SuppressWarnings("resource")
				Scanner sc1 = new Scanner(System.in);  
				String c = sc1.nextLine();
				RightList.add(c);
				LeftList.add(Integer.toString(i));
			}
			

		}
		
		/*Modify the question(coming soon)*/
		public void Modify(){
		    	
		}
}
