
public class InputConsole extends Input {
	
	/**
	 * Function coming soon for more input options 
	 */
	private static final long serialVersionUID = 1L;
	/**/
	public void getInput(){
		
	}

}
