import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.io.*;
import java.util.Vector;

public class Survey extends Main implements java.io.Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	protected  String Survey; 
	protected OuputConsole O = new OuputConsole();
	protected Vector<Question> questions = new Vector<Question>();
	protected Vector<RCA> respones = new Vector<RCA>();

	public Survey() {
		
	}
	/*Prompts the user to type in the name of the survey 
	 * and sets the Survey name to the users input and calls the QuestionMenu */
	public Survey SetSurvey() {
		
		System.out.println("type name of survey");
		Scanner sc = new Scanner(System.in);  
		String name= sc.nextLine();
		Survey= name;
		QuestionMenu();
		sc.close();
		
		return this;
		
		
		
	}
	/*Question Menu is called and the user is prompted 
	 * to pick a question or quit. Then the question object is created. */
	public void QuestionMenu(){
		
		System.out.println("1) Add a new T/F question ");
		System.out.println("2) Add a new multiple choice question ");
		System.out.println("3) Add a new short answer question ");
		System.out.println("4) Add a new essay question ");
		System.out.println("5) Add a new matching questione ");
		System.out.println("6) Add a new ranking question ");
		System.out.println("7) back ");

		System.out.println("Select One option from above ");
		@SuppressWarnings("resource")
		Scanner sc = new Scanner(System.in);
		
		//User input for the question is used to generate the question and adds to question vector 
		try{
			Question Question = null; 
			int i = sc.nextInt();
			switch(i) {
			case 1: 				   
				   System.out.println("T/F:");
				   Question = new TrueFalse(); 
				   Question.setQuestion();   
				   break;
			case 2: 
				   System.out.println("MC ");
				   Question = new MC(); 
				   Question.setQuestion(); 
				   break;
			case 3: 
				    System.out.println("SA ");
				    Question = new SA(); 
				    Question.setQuestion();
					break;
			case 4: 
				    System.out.println("Essay");
				    Question = new Essay(); 
				    Question.setQuestion();
					break;
			case 5: 
					System.out.println("Matching");
					Question = new Matching(); 
					Question.setQuestion();
					break;
			case 6: 
				    System.out.println("Ranking");
				    Question = new Ranking(); 
				    Question.setQuestion();
				    break;
			case 7: 
				super.SurveyMenu();
			    break;

	        default:
				System.out.println("Error Please select a valid option ");
				QuestionMenu();
	        }
			questions.add(Question);	
			QuestionMenu();
		}
		catch(Exception e){
			System.out.println("Error Please select a valid option");
			QuestionMenu();
		}
		

	
	}
	
	/*sets the vector questions to the questions provided*/
	public void setQuestions(Vector<Question> questions) {
		this.questions = questions;
		}
	
	/*returns the surveys vector of question*/
	public Vector<Question> getQuestions() {
		return this.questions;
		}
	
	/*Display the survey to console*/
	public void displaySurvey(){
		System.out.println("Displaying the survey with the questions created \n");
		this.O.display("Name of the Survey - "+this.Survey+"\n");
		for( int i =0; i<questions.size(); i++){
			questions.get(i).display(this.O);
		}
		this.O.display("\n");
	}
	/*Save the Survey in serialized form*/
	public void saveSurvey(Survey newSurvey, String t){
	      
	      try {
	    	  String savestr;
	    	  if(t.equals("survey"))
		        	  savestr = "SurveyList.txt";
		         else
		        	  savestr = "TestList.txt"; 
	    	  
	    	 File f = new File(savestr);

	    	 PrintWriter writer = null;
	    	 if ( f.exists() && !f.isDirectory() ) {
	    		 writer = new PrintWriter(new FileOutputStream(new File(savestr),true));
	    		 writer.println(this.Survey);
	    		 writer.close();
	    	 }
	    	 else {
	    		 writer = new PrintWriter(savestr);
	    		 writer.println(this.Survey);
	    		 writer.close();
	    	 }
	    	 
	         FileOutputStream fileOut = new FileOutputStream(this.Survey+".ser");
	         ObjectOutputStream out = new ObjectOutputStream(fileOut);
	         out.writeObject(this);
	         out.close();
	         fileOut.close();
	         System.out.printf("Serialized data is saved in /"+ this.Survey + ".ser");
	      }catch(IOException i) {
	         i.printStackTrace();
	      }
	      
	}
	/*Load the survey with a given type(Survey or Test) and */
	public static  Survey loadSurvey(String string,String t) throws FileNotFoundException{
		
		Survey LoadedSurvey= new Survey();
		System.out.println("Please select a file to load:");
		
		
		@SuppressWarnings("resource")
		Scanner sc = new Scanner(new File(string));
		List<String> lines = new ArrayList<String>();
		
		while (sc.hasNextLine()) {
		  lines.add(sc.nextLine());
		}

		String[] arr = lines.toArray(new String[0]);
		int i =1; 
		
		for (String p : arr){
			System.out.println(i+") "+ p); i++;
		}
		    
			
		@SuppressWarnings("resource")
		Scanner sc1 = new Scanner(System.in);
		int i1 = sc1.nextInt();
		 

		try {
			 
	         FileInputStream fileIn = new FileInputStream(arr[i1-1]+".ser");
	         ObjectInputStream in = new ObjectInputStream(fileIn);
	         if(t.equals("survey"))
	        	 LoadedSurvey = (Survey) in.readObject();
	         else
	        	 LoadedSurvey = (test) in.readObject();
	         in.close();
	         fileIn.close();
	      }catch(IOException i11) {
	         i11.printStackTrace();
	         System.out.println("File  not found");
	      }catch(ClassNotFoundException c) {
	         System.out.println("Employee class not found");
	         c.printStackTrace();
	         
	      }

			return LoadedSurvey;
	}
	
	

}
