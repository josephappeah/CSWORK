import java.util.Scanner;

public class SA extends Essay {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	protected int WordLimit;
	
	public SA(){
		
	}
	/*Get the Prompt from the user for the SA*/
	public void getPrompt() {
		
		System.out.println("Enter the prompt or your short answer question:");
		@SuppressWarnings("resource")
		Scanner sc = new Scanner(System.in);
		String i = sc.nextLine();
		SetPrompt(i +"\n");
	}
	/*Sets the question and set the word limit prompted from the user*/
	public void setQuestion(){

		getPrompt();
		System.out.println("Enter wordlimit in number of charters");
		@SuppressWarnings("resource")
		Scanner reader1 = new Scanner(System.in);
		while (!reader1.hasNextInt()) {
			   System.out.println("int, please!");
			   reader1.nextLine();
			}
		int n = reader1.nextInt();
		setWordlimit(n);
		
	}
	/*return the wordlimit*/
	public int getWordlimit() {
		return this.WordLimit;
		}
	/*sets the wordlimit*/
	public void setWordlimit(int n) {
		this.WordLimit = n;
		}
	/*Display to the console the SA*/
	public void display(Output O){
		O.display(prompt);
		O.display("word limit is:"+ WordLimit +"\n");
	}
	public void Modify(){
		
	}
}
