import java.util.Scanner;
import java.util.Vector;

public class MC extends Question implements java.io.Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	protected Vector<String> choices = new Vector<String>(); 
	
	public MC(){
		
	}
	/*Get the Prompt from the user for the MC*/
	public void getPrompt() {
		System.out.println("Enter the prompt or your multiple choice question:");
		@SuppressWarnings("resource")
		Scanner sc = new Scanner(System.in);
		String i = sc.nextLine();
		SetPrompt(i +"\n");
	}
	/*Sets the question for the MC and loads the vector choices*/
	public void setQuestion() {
		
		getPrompt();
		System.out.println("Enter the number of choices for your multiple choice question");
		@SuppressWarnings("resource")
		Scanner sc = new Scanner(System.in);
		while (!sc.hasNextInt()) {
			   System.out.println("int, please!");
			   sc.nextLine();
			}
		int n = sc.nextInt();
		
		for( int i=1; i<=n;i++){
			System.out.println("Enter choice " + "#"+i+".");
			@SuppressWarnings("resource")
			Scanner sc1 = new Scanner(System.in);  
			String c = sc1.nextLine();
			choices.add(c);

		}
		

		
	} 
	/*Sets the question*/
	public void setChoices(Vector<String> choices) {
		
		this.choices = choices;
	}
	/*returns the choices vector for the question */
	public Vector<String> getChoices(){
		
		return this.choices;
	}
	/*Display to console the question and the choices*/
	public void display(Output O){
		
		O.display(this.prompt);
		for(int i=0;i<choices.size();i++){
			O.display( (char)(i+65)+") " +choices.elementAt(i)+" ");	
			}
		O.display("\n");
	}
	
	public void Modify(){
		
	}
	

}
