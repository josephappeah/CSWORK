import java.util.Scanner;
import java.util.Vector;

public class RCA implements java.io.Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public Vector<String> RCA=new Vector<String>();

	public RCA(){
		
	}
	/*This places the respones in the vector of strings for each type of question*/
	public void addResponse(int option, Vector<String> right, int wL, Vector<String> left){
		try{
		switch(option){
		case 1:
			
			System.out.println("Enter Correct answer T/F:");
			Scanner TF = new Scanner(System.in);  
			String answer= TF.nextLine();
			
			if(!(answer.equals("T") || answer.equals("F")) ){
				System.out.println("Error Please enter T or F");
				addResponse(option, right, wL, left);	
			}
			RCA.addElement(answer);
			break;

		case 2: 
			
			System.out.println("Enter number of correct answers for the multiple choice question ");
			Scanner MC = new Scanner(System.in);
			while (!MC.hasNextInt()) {
				   System.out.println("int, please!");
				   MC.nextLine();
				}
			int n1 = MC.nextInt();
			System.out.println("Please enter the correct response ");
			Scanner MCR = new Scanner(System.in);
			for (int i =0; i < n1; i ++ ){
				System.out.print((i+1)+") ");
				String MCanswer= MCR.nextLine();
				
				RCA.addElement((i+1)+") "+MCanswer);
			}
			break;
			
		case 3: 
			System.out.println("Please enter the correct response in the correct short answer. World length in characters is: "+ wL);
			Scanner SAR = new Scanner(System.in);
			String SAA= SAR.nextLine();
				
			if(SAA.length() > wL){
				System.out.println("Answer is longer then word length. Reenter the Answer. World length in characters is: "+ wL);
				addResponse(option, right, wL, left);
			}
			RCA.addElement(SAA);
			
			break;
			
		case 5:
			System.out.println("Please enter the correct match ex: Matching a Matching b  ");
			Scanner MatchR = new Scanner(System.in);
			for (int i =0; i < right.size(); i ++ ){
				System.out.print((i+1)+") "+ right.get(i)+" matches with: " );
				String Matchanswer= MatchR.nextLine();
				if(!left.contains(Matchanswer)) {
					System.out.println("please enter a valid match from the choices provided"); 
					addResponse(option, right, wL, left); 
					
				}
				RCA.addElement((i+1)+") "+Matchanswer);
			}
			
			break;

		case 6:
			
				System.out.println("Please enter the correct response in the correct ranking order ");
				Scanner RankR = new Scanner(System.in);
				
				for (int i =1; i < right.size()+1; i++ ){
					System.out.println(i);
					String Rankanswer= RankR.nextLine();
					
					if(!right.contains(Rankanswer)) {
						System.out.println("please enter a valid match from the choices provided"); 
						i=0;
						addResponse(option, right, wL, left); 
						
					}
					RCA.addElement(Rankanswer);
				}
		
				break;
			
		default:
			String input;
			input = "Not applicable in essay type of questions ";
			RCA.addElement(input);
			break;
		}
		}
		catch(Exception e){
			System.out.println("Error Please select a valid option");
			addResponse(option, right, wL, left);
		}
		
	}
	public void editResponse(){
		
	}
	public void setRCA(Vector<String> rca){
		RCA = rca;
	}
	public Vector<String> getRCA(){
		return RCA;
		
	}
	public void setResponse(){
		
	}
	
	public void display(Output o) {
	for(int i=0;i<RCA.size();i++){
		o.display(RCA.elementAt(i)+" ");
			}
		o.display("\n");
		}
	
}
