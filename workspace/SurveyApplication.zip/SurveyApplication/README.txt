Sunny Shah 
CS350 
Homework 2 

The survey and test objects are serilized into a file in the root of the zip file.

Samples files are also located on the root of the zip. 

/SurveyApplication/SurveyList
/SurveyApplication/TestList 
/SurveyApplication/Test
/SurveyApplication/Survey1 
