Sunny Shah 
CS350 
Homework 3 

The survey and test objects are serilized into a file in the root of the zip file.

Samples files are also located on the root of the zip. 

/SurveyApplication/SurveyList
/SurveyApplication/TestList 
/SurveyApplication/Test
/SurveyApplication/Survey 
/SurveyApplication/MC


Couple Notes: 

1. Once the Survey/Test is taken the Survey most be saved inorder to be correctly graded/tabulated. 
2. The save function save the created file and does not overwrite perivous saves. Thus, after taking the Survey/Test one must save and then 
choose the latest saved file to get the correct tabulations. This also goes for modifications the file that is being modified needs to be saved
in order for those modifications to be validated within the system. 
3. Each Survey/Test has three pairs of respones (added a MC one for another round of testing with one response)  
4. Everything should be functioning correctly if the correct steps are taken while going through the taking and moditcation. Just basically save 
everytime anychange has been made to any of the Survey or Test. 