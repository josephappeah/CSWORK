
public class Output implements java.io.Serializable {
	
	/**
	 * Function to handle all types output coming soon 
	 */
	private static final long serialVersionUID = 1L;
	public Output(){
		
	}
	public void display(String prompt){
		
	}
}
