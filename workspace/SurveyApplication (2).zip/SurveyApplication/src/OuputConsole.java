
public class OuputConsole extends Output {
	
	/**
	 * function to handle console output
	 */
	private static final long serialVersionUID = 1L;

	public void display(String output){
		
		System.out.print(output);
	}
}
