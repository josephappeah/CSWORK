
public class Input implements java.io.Serializable {

	/**
	 * Function coming soon to handle all input 
	 */
	private static final long serialVersionUID = 1L;
	public Input(){
		
	}
	public void getInput(){
		
	}

}
